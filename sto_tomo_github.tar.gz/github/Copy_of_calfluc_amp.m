fluctuations = [];
stations_latitude = [];
stations_longitude = [];
stations_distance = [];
event_latitude = [];
event_longitude = [];
event_depth = [];
amp_ref = [];
amp_data = [];

workdir = dir('*_*_*_*');

for j = 1:length(workdir)

    foldername = strcat(workdir(j).name, '/');

    a= (foldername ~= '_');
    
    clear srcla;
    clear srclo;
    clear mag;
    clear dep;
    i = 1;
    n = 1;
    while a(i)
        mag(n) = foldername(i);
        i = i+1;
        n = n+1;
    end
    n = 1;
    i = i+1;
    while a(i)
        srcla(n) = foldername(i);
        i = i+1;
        n = n+1;
    end
    n = 1;
    i = i+1;
    while a(i)
        srclo(n) = foldername(i);
        i = i+1;
        n = n+1;
    end
    n = 1;
    i = i+1;
    while foldername(i) ~= '.'
        dep(n) = foldername(i);
        i = i+1;
        n = n+1;
    end
    
    
    
    mag = str2num(mag);
    srcla = str2num(srcla);
    srclo = str2num(srclo);
    dep = str2num(dep)/1000;

    saclist = dir(strcat(foldername,'*SLC'));
    synlist = dir(strcat(foldername,'*sac'));
    if length(synlist) ~= length(saclist)
	display('wrong sac file at')
	display(j)
	continue;
    end
    amps_syn = [];
    amps_sei = [];
    stla = [];
    stlo = [];
    dist = [];
    [j length(saclist)]
    for i = 1:length(saclist)
        sacdata = rdsac(strcat(foldername,saclist(i).name));
        fs = round(1/sacdata.HEADER.DELTA);
        len = length(sacdata.d);
        if len < 1000
            display('bug at')
            [j i]       
            sacdata = rdsac(strcat(foldername,synlist(i).name));
            fs = round(1/sacdata.HEADER.DELTA);
            len = length(sacdata.d);
        end

        
        wavelet = sacdata.d(round(len/7)*3+1:round(len/7)*4);
        [a, b] = pmtm(wavelet,4,len,fs);
        fre=0.01:0.01:2;
        amp = interp1(b,a,fre);
        amp = amp(round(fre*10000)==7000);
        amps_sei(i) = log(amp);

        sacdata=rdsac(strcat(foldername,synlist(i).name));
        fs=round(1/sacdata.HEADER.DELTA);
        len=length(sacdata.d);
        wavelet=sacdata.d(round(len/7)*3+1:round(len/7)*4);
        [a,b]=pmtm(wavelet,4,len,fs);
        fre=0.01:0.01:2;
        amp=interp1(b,a,fre);
        amp=amp(round(fre*10000)==7000);
        amps_syn(i)=log(amp);    
        stla(i)=sacdata.HEADER.STLA;
        stlo(i)=sacdata.HEADER.STLO;
        dist(i)=distance(srcla,srclo,sacdata.HEADER.STLA,sacdata.HEADER.STLO);        
    end
    
    if length(amps_sei)>20
    baddata=abs(amps_sei-mean(amps_sei))>3;
    amps_sei(baddata)=[];
    amps_syn(baddata)=[];
    stla(baddata)=[];
    stlo(baddata)=[];
    dist(baddata)=[];
    shift=ones(length(amps_sei),1)\(amps_syn-amps_sei)';    
    fluctuations(1+length(fluctuations):length(amps_sei)+length(fluctuations))=amps_sei-(amps_syn-shift);
    stations_latitude(1+length(stations_latitude):length(amps_sei)+length(stations_latitude))=stla;
    stations_longitude(1+length(stations_longitude):length(amps_sei)+length(stations_longitude))=stlo;
    stations_distance(1+length(stations_distance):length(amps_sei)+length(stations_distance))=dist;
    event_latitude(1+length(event_latitude):length(amps_sei)+length(event_latitude)) = srcla;
    event_longitude(1+length(event_longitude):length(amps_sei)+length(event_longitude)) = srclo;
    event_depth(1+length(event_depth):length(amps_sei)+length(event_depth)) = dep;
    amp_ref(1+length(amp_ref):length(amps_sei)+length(amp_ref)) = amps_syn-shift;
    amp_data(1+length(amp_data):length(amps_sei)+length(amp_data)) = amps_sei;
    display('got data')
    end
    
end

%save flutuations.mat

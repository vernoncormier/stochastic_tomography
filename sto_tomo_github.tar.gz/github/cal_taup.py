from obspy.taup import TauPyModel
model = TauPyModel(model="ak135")
for i in range(1,101):
	arrivals = model.get_travel_times(500, i)
	arrivals = model.get_travel_times(500, i)
	print(str(arrivals[0].ray_param)+' '+str(arrivals[0].incident_angle))

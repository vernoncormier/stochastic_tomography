fluctuations = [];
stations_latitude = [];
stations_longitude = [];
stations_distance = [];
event_latitude = [];
event_longitude = [];
event_depth = [];

workdir=dir('*_*_*_*_*');
offn=0;

for j=1:length(workdir)

    foldername=strcat(workdir(j).name,'/');
    a=foldername~='_';
    
    clear srcla;
    clear srclo;
    clear mag;
    clear dep;
    i = 1;
    n = 1;
    while a(i)
        mag(n) = foldername(i);
        i = i+1;
        n = n+1;
    end
    n = 1;
    i = i+1;
    while a(i)
        srcla(n) = foldername(i);
        i = i+1;
        n = n+1;
    end
    n = 1;
    i = i+1;
    while a(i)
        srclo(n) = foldername(i);
        i = i+1;
        n = n+1;
    end
    n = 1;
    i = i+1;
    while foldername(i) ~= '.'
        dep(n) = foldername(i);
        i = i+1;
        n = n+1;
    end
    
    mag=str2num(mag);
    srcla=str2num(srcla);
    srclo=str2num(srclo);
    dep = str2num(dep)/1000;




    saclist = dir(strcat(foldername,'**.SLC'));
    synlist = dir(strcat(foldername,'XX.*sac'));
    if length(synlist) ~= length(saclist)
        display('wrong sac file at')
        display(j)
        continue;
    end
 


    stla = [];
    stlo = [];
    dist = [];
    time_shift = [];
    waveform = 0;
    
    if length(saclist) < 20
        continue;
    end
    
    for i=1:length(saclist)
        
        syndataraw=rdsac(strcat(foldername,synlist(i).name));
        seidataraw=rdsac(strcat(foldername,saclist(i).name));
        len=length(seidataraw.d);
        synlen=length(syndataraw.d);
        if len < 1000 || len==2885 ||len==11955 ||len==8274
            display('bug at')
            [j i]
            syndataraw=rdsac(strcat(foldername,synlist(i).name));
            seidataraw=rdsac(strcat(foldername,synlist(i).name));
            len = length(seidataraw.d);
        end

%         seidataraw.d(1:len/6)=0;
%         seidataraw.d(len/6*4:end)=0;
%         syndataraw.d(length(syndataraw.d)/6*4:end)=0;
        rawdata=seidataraw.d .* hann(length(seidataraw.d));
        waveform=waveform+interp1(1:len,rawdata/max(abs(rawdata)),1:0.05/seidataraw.HEADER.DELTA:len);
    end
    waveform=waveform/length(saclist);
    shiftwave=zeros(1,4800);
    for i=1:length(saclist)
        
        seidataraw=rdsac(strcat(foldername,saclist(i).name));
        len=length(seidataraw.d);
        rawdata=seidataraw.d .* hann(length(seidataraw.d));
        seidata=interp1(1:len,rawdata/max(abs(rawdata)),1:len/4800:len);
        [r,lag]=xcorr(waveform,seidata);
        [~,I]=max(r); %use r instead of r^.2. minus r mean negatively correlated
        I=lag(I);
        if abs(I) > 400
            display('warning over shift');
            continue;

        end
        shiftwave(400:4400)=shiftwave(400:4400)+seidata(400-I:4400-I);
    end
    shiftwave=shiftwave/max(shiftwave);

    %plot(waveform+j); hold on;
    for i=1:length(saclist)
        seidataraw=rdsac(strcat(foldername,saclist(i).name));
        len=length(seidataraw.d);
        rawdata=seidataraw.d .* hann(length(seidataraw.d));
        seidata=interp1(1:len,rawdata/max(abs(rawdata)),1:len/synlen:len);
        [r,lag]=xcorr((shiftwave),(seidata));
        [~,I]=max(r.^2);
        time_shift(i)=lag(I);
           if abs(time_shift(i))*0.05 >5
               time_shift(i)=0;
               subplot(2,1,1);hold on;
               plot(waveform+offn,'r','LineWidth',1);
               subplot(2,1,2);hold on;
               plot(seidata+offn,'b');
               offn=offn+1;
           end
        stla(i)=seidataraw.HEADER.STLA;
        stlo(i)=seidataraw.HEADER.STLO;
        dist(i)=distance(srcla,srclo,stla(i),stlo(i));
    end

    [j length(saclist)]

    fluctuations(1+length(fluctuations):length(time_shift)+length(fluctuations))=time_shift*0.05*2*pi*0.7;
    stations_latitude(1+length(stations_latitude):length(time_shift)+length(stations_latitude))=stla;
    stations_longitude(1+length(stations_longitude):length(time_shift)+length(stations_longitude))=stlo;
    event_latitude(1+length(event_latitude):length(time_shift)+length(event_latitude))=srcla;
    event_longitude(1+length(event_longitude):length(time_shift)+length(event_longitude))=srclo;
    stations_distance(1+length(stations_distance):length(time_shift)+length(stations_distance))=dist;
end
save phase_fluct.mat fluctuations

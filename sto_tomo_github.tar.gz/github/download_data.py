import sys
output = open('process.log','w')
sys.stdout = output

import json
inputdata = json.load(open('input.txt'))
print(inputdata)

import os

from obspy.clients.fdsn import Client as fdsnClient
from obspy.clients.iris import Client as irisClient
from obspy 		import UTCDateTime
from obspy		import read
from obspy.core.event 	import read_events   ##this is read event function for reading quakeml files
from obspy		import read_inventory
from obspy.taup 	import TauPyModel
from obspy.geodetics 	import locations2degrees 


dataclient = fdsnClient("IRIS")
calclient  = irisClient()

event_mintime = UTCDateTime(inputdata["event_mintime"])
event_maxtime = UTCDateTime(inputdata["event_maxtime"])
print(event_mintime)
print(event_maxtime)

eventgroup=read_events("eventslist") ##this is from iris gcmt service for event group with moment tonsor
print(eventgroup)

#download station list data and save into stationlist file
dataclient.get_stations(filename="stationslist",starttime=event_mintime, endtime=event_maxtime, channel=inputdata["channel"], minlatitude=inputdata["station_latitude_min"], maxlatitude=inputdata["station_latitude_max"], minlongitude=inputdata["station_longitude_min"], maxlongitude=inputdata["station_longitude_max"])
#read from stationlist file
stationgroup=read_inventory("stationslist")
print(stationgroup)

# define arrival time ref model and prefilter to remove instrument response
# the iasp91 is the only model supported by taup here
model=TauPyModel(model="ak135")
pre_filt=(0.01,0.02,10,15)

for i in range(0,len(eventgroup)):
	# get gcmt event id for later use	
	eventid=eventgroup[i].origins[0].resource_id.id.split('/')[-1].split('#')[0]
	# make directory to save data by event
	foldername='./'+str(eventgroup[i].magnitudes[0].mag)+'_'+str(eventgroup[i].origins[0].latitude)+'_'+str(eventgroup[i].origins[0].longitude)+'_'+str(eventgroup[i].origins[0].depth)+'_'+eventid+'/'
	os.makedirs(os.path.dirname(foldername))
	for j1 in range(len(stationgroup.networks)):
		for j2 in range(len(stationgroup[j1].stations)):
			distance = locations2degrees(eventgroup[i].origins[0].latitude, eventgroup[i].origins[0].longitude, stationgroup[j1].stations[j2].latitude, stationgroup[j1].stations[j2].longitude)
			#check if further than 95 degree to avoid Pdiff arrivals
			if distance > 95:
				print "too far away"
				break
			else:
				arrivals = model.get_travel_times(eventgroup[i].origins[0].depth/1000, distance,phase_list=[inputdata["phase"]]);
				arrivaltime = arrivals[0].time
				fivem_before_arrival = eventgroup[i].origins[0].time + arrivaltime - 120
				fivem_after_arrival  = eventgroup[i].origins[0].time + arrivaltime + 120
				# make sure ther the station is working to record this event
				if fivem_before_arrival > stationgroup[j1].stations[j2].creation_date and (stationgroup[j1].stations[j2].end_date is None or  fivem_after_arrival < stationgroup[j1].stations[j2].end_date):
					try:
						filename=foldername+stationgroup[j1].code+'_'+stationgroup[j1].stations[j2].code+'.SAC'
						# get waveform (Here the fivem is the time window for the waveform, not necessarily five min)
						trace = dataclient.get_waveforms(network=stationgroup[j1].code, station=stationgroup[j1].stations[j2].code, location=inputdata["location"], channel=inputdata["channel"], starttime=fivem_before_arrival, endtime=fivem_after_arrival, attach_response=True)
						# remove the instrument response and output into VEL, water level is defaulted at 60.
						trace.remove_response(output='VEL',pre_filt=pre_filt,water_level=60,taper=True,zero_mean=True)
						trace.write(filename, format="SAC")
						print(trace)
					except:
						print("no data in %s",stationgroup[j1].stations[j2].code)
				#else:
					#print("not in time range",s120_before_arrival,s120_after_arrival,stationgroup[j1].stations[j2].creation_date,stationgroup[j1].stations[j2].termination_date)
		print("finished %d event in %d, %d network in %d") %(i+1, len(eventgroup), j1+1, len(stationgroup.networks))
	#dataclient.get_waveforms_bulk(bulk=bulk,filename="seismograms_event"+str(i),attach_response=True)
	#traces=read("seismograms_event"+str(i))
	#print(traces)
print('done')
output.close()

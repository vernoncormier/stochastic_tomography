clear stations;
clear srclist;
%clear fluctuations;
n_traces=1;

workdir=dir('*_*_*_*_*');

for j=1:length(workdir)

    foldername=strcat(workdir(j).name,'/');
    a=foldername~='_';
    
    clear mag; 
    clear srcla;
    clear srclo;
    clear eventid;
    i=1;
    n=1;
    while a(i)
        mag(n)=foldername(i);
        i=i+1;
        n=n+1;
    end
    n=1;
    i=i+1;
    while a(i)
        srcla(n)=foldername(i);
        i=i+1;
        n=n+1;
    end
    n=1;
    i=i+1;
    while a(i)
        srclo(n)=foldername(i);
        i=i+1;
        n=n+1;
    end
    srclist(j,3)=str2num(mag);
    srclist(j,1)=str2num(srcla);
    srclist(j,2)=str2num(srclo);

    saclist=dir(strcat(foldername,'*SLC'));
    for i=1:length(saclist)
        sacdata=rdsac(strcat(foldername,saclist(i).name));
%        fs=round(1/sacdata.HEADER.DELTA);
        [j i]
%        len=length(sacdata.d);

%        wavelet=sacdata.d(round(len/7)*3+1:round(len/7)*4);
%        [a,b]=pmtm(wavelet,4,len,fs);
%        fre=0.01:0.01:2;
%        amp=interp1(b,a,fre);
%        amp=amp(fre==0.5);
%        if ((log(amp) > -25) || (log(amp)<-37)) 
%            continue;
%        end
        
%        fluctuations(n_traces)=amp;
        stations(1,n_traces)=sacdata.HEADER.STLA;
        stations(2,n_traces)=sacdata.HEADER.STLO;
%        stations(3,n_traces)=distance(srcla,srclo,sacdata.HEADER.STLA,sacdata.HEADER.STLO);
%	stations(4,n_traces)=mag;
        n_traces=n_traces+1;    
    end

end

save maps.mat srclist stations
%save flutuations.mat

import os

import math
from numpy import linalg as LA

from obspy 		import UTCDateTime
from obspy		import read
from obspy 		import read_events
from obspy		import read_inventory
from obspy.geodetics 	import locations2degrees


eventgroup=read_events("eventslist")
print(eventgroup)

stationgroup=read_inventory("stationslist")
print(stationgroup)

for i in range(len(eventgroup)):
	for j1 in range(len(stationgroup.networks)):
		for j2 in range(len(stationgroup[j1].stations)):
					try:
						filename='./'+str(eventgroup[i].magnitudes[0].mag)+'_'+str(eventgroup[i].origins[0].latitude)+'_'+str(eventgroup[i].origins[0].longitude)+'_'+str(eventgroup[i].origins[0].depth)+'/'+stationgroup[j1].code+'_'+stationgroup[j1].stations[j2].code+'.SAC.SLC'
						os.remove(filename)
						print("done")
					except:
						pass
				#else:
					#print("not in time range",s120_before_arrival,s120_after_arrival,stationgroup[j1].stations[j2].creation_date,stationgroup[j1].stations[j2].termination_date)
		print("finished %d event in %d, %d network in %d") %(i+1, len(eventgroup), j1+1, len(stationgroup.networks))
	#dataclient.get_waveforms_bulk(bulk=bulk,filename="seismograms_event"+str(i),attach_response=True)
	#traces=read("seismograms_event"+str(i))

 % Pre-calculate functions for a, tau, tau, R, theta
% 
% 
% clear all;
% close all;
% 
 iasp = load('IASP91');
 c_ref = interp1(iasp(:,1),iasp(:,2),1:2000);
% the following is to calculate the tau function and its derivatives
 from_taup;
 qs = taup_data(:, 1) / 6371;
 angles = taup_data(:,2);
 distances = 41:90;
% 
 dq = (max(qs) - min(qs)) / 1000;
 q_mesh = min(qs):dq:max(qs);
% 
 tau_mesh=zeros(length(q_mesh),length(c_ref));%tau is a function of both q and z
 for i=1:length(q_mesh)
     for j=2:length(c_ref);
         tau_mesh(i,j)=trapz(1:j,sqrt(1./c_ref(1:j).^2-q_mesh(i)^2));
     end
 end
 d1tau_mesh=zeros(length(q_mesh)-1,length(c_ref));
 d2tau_mesh=zeros(length(q_mesh)-2,length(c_ref));
 for j=1:length(c_ref)
     d1tau_mesh(:,j)=diff(tau_mesh(:,j))/dq;
     d2tau_mesh(:,j)=diff(diff(tau_mesh(:,j))/dq)/dq;
 end
 d1tau_mesh(1001,:)=d1tau_mesh(1000,:);
 d2tau_mesh(1000,:)=d2tau_mesh(999,:);
 d2tau_mesh(1001,:)=d2tau_mesh(999,:);
 save tau.mat tau_mesh d1tau_mesh d2tau_mesh q_mesh

% 
  index=q_mesh<0;%initiate an logical zeros
  for i = 1:length(qs)
  [ buffer1 , buffer2]=min(abs(q_mesh-qs(i)));
  index(buffer2)=true;
  end
  
  tau=tau_mesh(index,:);
  d1tau=d1tau_mesh(index,:);
  d2tau=d2tau_mesh(index,:);
% 
% 
 %theta is a function of q , z and kappa
  kmap=0.0001:0.0001:0.3;
% the following is for log sampling of wavenumber
 % %kmap=logspace(-3,-1,100);
 theta=zeros(length(qs),length(c_ref),length(kmap));
  w=2*pi*0.5;
 for i=1:length(qs)
     theta(i,:,:) = 0.5 * d2tau(i,:)' * kmap.^2 / w^2;
 end
 save theta.mat theta

%a is a function of q and z
 a=zeros(length(qs),length(c_ref));
 k=w./c_ref;
 for i = 1:length(qs)
     kq=w.*sqrt(1./c_ref.^2-qs(i)^2);
     a(i,:)=k.^2./kq;
 end
 save a.mat a

% save the cordinates and wavenumber, which is the independent variables of a/q//theta functions
 save cord.mat qs distances angles kmap w tau d1tau d2tau

% % R is a function of q1 q2 z and lag;
% % %for tcf case, R is same with surface lag. tcfR=[1:600]*length(c_ref);
% % %for acf case lag at surface is zeros. R=abs(t2'-t1')
tcfR=zeros(600,length(c_ref));
for i=1:length(c_ref)
    tcfR(:,i)=1:600;
end

acfR=zeros(length(qs)*length(qs),length(c_ref));
for i1= 1:length(qs)
    for i2= 1:length(qs)
        for z = 1:length(c_ref)
        acfR((i1-1)*(length(qs))+i2,z)=abs(d2tau(i1,z)-d2tau(i2,z));
        end
    end
end
save R.mat acfR tcfR

% % 
% % %R=zeros(600,length(c_ref));
% % %R=|(x1-r1)-(x2-r2)|,which is R=|x1-x2-r1+r2| =|lag-r1+r2| 
% % %Since in d1tau, all numbers are negative, we use lag+r1-r2
% % n=1;
% % for x=-300:299
% %     r1=d1tau1;
% %     r2=d1tau2;
% %     R(n,:)=abs(x+r2-r1);
% %     n=n+1;
% % end

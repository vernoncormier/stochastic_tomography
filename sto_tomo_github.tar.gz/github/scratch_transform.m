%% The original matrix's dimension is 300 X 3000000, 
%% where 3000000 = 3000 X 1000 are the wave number and depth integration spacings
%% Assume integration over wave number then depth: 
%% Target spectrum has a depth of 1000km and resolution of 25km , wave-number from 0 - 0.3 (km^-1) with resolution of 0.03 (km^-1)
%% Therefore we need to transform (re-sample) the target spectrum from (40 X 100) X 1 to (1000 X 3000) X 1,
%% which means rescale wavenumber with a factor of 30 then rescale depth with a factor of 25

%% Initialize memory
T1 = zeros(3000,4000);
T2 = zeros(4000*30*25,3000);

%% Build T1 transform matrix 
for i = 1 : 100
buffer = zeros(30,4000);
buffer(:,i) = ones(30,1);
T1(30*(i-1)+1 : 30*i , :) = buffer;
end

%% Build T2 transform matrix 
for i = 1 : 25
buffer = zeros(4000*30,3000);
for j = 1:30
buffer((i-1)*3000+1:3000*i,:)=diag(ones(3000 , 1));
end
T2(4000*30*(i-1)+1 : 4000*30*i , :)=buffer;
end

%%Apply T1 and T2 on left of the original matrix New_M = M*T2*T1

load M.mat
Mapped_M = M*T2*T1;

save mapped_M.mat Mapped_M -v7.3;

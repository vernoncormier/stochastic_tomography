%  load a
%  load cord
%  load theta
%  iasp = load('IASP91');
%  c_ref = interp1(iasp(:,1),iasp(:,2),1:2000);
%  dh=1;
%  dk=kmap(2)-kmap(1);
%  zmap=1:2000;
clear q_mesh tau_mesh d1tau_mesh d2tau_mesh iasp tau d1tau d2tau

% % TCF case, the fluctuations are measured for same source. Coherences are
% % calculated at different receivers. It's a function of R for fixed q. 
% % Matrix dimension is Rs*(z*k)
% % If there is different qs. The matrix is qs * [Rs*(z*k)]

% % Here we choose incident waves of distances 60:5:80
% stop
incs=60:5:80;
for i = 1:5
    inc = incs(i);
    %q = qs(distances==inc);
    %tp = d1tau(distances==inc,:);
    %tpp = d2tau(distances==inc,:);
    a = as(distances==inc,:);
    the = squeeze(theta(distances==inc,:,:));
    
    matrixpp=zeros(300,1000*3000);
    matrixaa=zeros(300,1000*3000);
    
    R_map=-299:2:300;
    aatheta=sin(the).*sin(the);
    pptheta=cos(the).*cos(the);
    J_K_R=besselj(0,R_map'*kmap);
    
    for R = 1:300 
        for z = 1:1000
            aterm=a(z)*a(z);
            for k = 1:3000
                ppterm=pptheta(z,k);
                aaterm=aatheta(z,k);
                jterm=J_K_R(R,k);
                matrixpp(R,(z-1)*300+k)=0.5/pi*dh*aterm*ppterm*kmap(k)*dk*jterm;
                matrixaa(R,(z-1)*300+k)=0.5/pi*dh*aterm*aaterm*kmap(k)*dk*jterm;
            end
        end
    end
    save(strcat('matrix_tcf_',num2str(inc)),'matrixpp','matrixaa','-v7.3')                
end
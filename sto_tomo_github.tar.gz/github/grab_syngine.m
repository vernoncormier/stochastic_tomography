workdir=dir('*_*_*_*_*');

for j=1:length(workdir)

    foldername=strcat(workdir(j).name,'/');
    a=foldername~='_';
    
    clear mag; 
    clear srcla;
    clear srclo;
    clear depth;
    clear eventid;
    i=1;
    n=1;
    while a(i)
        mag(n)=foldername(i);
        i=i+1;
        n=n+1;
    end
    n=1;
    i=i+1;
    while a(i)
        srcla(n)=foldername(i);
        i=i+1;
        n=n+1;
    end
    n=1;
    i=i+1;
    while a(i)
        srclo(n)=foldername(i);
        i=i+1;
        n=n+1;
    end
    n=1;
    i=i+1;
    while foldername(i)~='_'
	depth(n)=foldername(i);
	i=i+1;
	n=n+1;
    end    
    n=1;
    i=i+1;
    while foldername(i)~='/'
        eventid(n)=foldername(i);
        i=i+1;
        n=n+1;
    end

    mag=str2num(mag);
    srcla=str2num(srcla);
    srclo=str2num(srclo);
    depth=str2num(depth);

    saclist=dir(strcat(foldername,'*SLC'));
    clear receivers;
    waveform = 0;
    for i=1:length(saclist)
        sacdata=rdsac(strcat(foldername,saclist(i).name));
        waveform = waveform + interp1(1:length(sacdata.d),...
            sacdata.d/max(abs(sacdata.d)),...
            1:length(sacdata.d)/4800:length(sacdata.d));
        receivers(i,1)=sacdata.HEADER.STLA;
        receivers(i,2)=sacdata.HEADER.STLO; 
       %plot(sacdata.t,sacdata.d);hold on;
    end
    waveform=waveform/max(abs(waveform));
    shiftwave=0;
    for i=1:length(saclist)
        
        seidataraw=rdsac(strcat(foldername,saclist(i).name));
        len=length(seidataraw.d);
        rawdata=seidataraw.d .* hann(length(seidataraw.d));
        seidata=interp1(1:len,rawdata/max(abs(rawdata)),1:len/4800:len);
        [r,lag]=xcorr(waveform,seidata);
        [~,I]=max(r); %use r instead of r^.2. minus r mean negatively correlated
        I=lag(I);
        subplot(3,1,1);xlabel('timestep');ylabel('a');plot(seidata(2200:2600));hold on;
        subplot(3,1,2);xlabel('timestep');ylabel('b');plot(seidata(2200-I:2600-I));hold on;
        shiftwave=shiftwave+seidata(1000-I:3000-I);
    end
    subplot(3,1,3);hold on;xlabel('timestep');ylabel('c');plot(shiftwave(1200:1600)/max(shiftwave).*tukeywin(401,0.75)','LineWidth',2)
    
    
    stop
    if ~ isempty(saclist)
        cd(foldername);
        fid = fopen('syngine.request','wt');
        fprintf(fid,'model=ak135f_1s\n');
        fprintf(fid,'units=velocity\n');
        fprintf(fid,'components=Z\n');
        fprintf(fid,'eventid=GCMT:%s\n',eventid);
        fprintf(fid,'starttime=P-120\n');
        fprintf(fid,'endtime=240\n');
        fprintf(fid,'cstf-relative-origin-time-in-sec=1.0\n');
        fprintf(fid,'cstf-sample-spacing-in-sec=0.4\n');
        fprintf(fid,'cstf-data=');
        window=hann(15);
        waveform=shiftwave(1401:8:1520).*window';
        
        for i=1:14
            fprintf(fid,'%0.6f,',waveform(i));
        end
        fprintf(fid,'%0.6f\n',waveform(end));
        fprintf(fid,'%0.6f %0.6f\n',receivers.');
        fclose(fid);
        cd ..
    end
end
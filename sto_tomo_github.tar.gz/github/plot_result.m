load cohe_all
moving_average=1;
subplot(3,2,3)
plot(5:5:1000,smooth(cohe_all(1:200),moving_average),'bo-');
xlabel('lag distance (km)');
ylabel('log amplitude coherence');

subplot(3,2,4)
plot(5:5:1000,smooth(cohe_all(301:500),moving_average),'bo-')
xlabel('lag distance (km)');
ylabel('phase coherence');

subplot(3,2,1)
plot(5:5:1000,smooth(cohe_all(601:800),moving_average),'bo-')
xlabel('lag distance (km)');
ylabel('log amplitude coherence');

subplot(3,2,2)
plot(5:5:1000,smooth(cohe_all(901:1100),moving_average),'bo-')
xlabel('lag distance (km)');
ylabel('phase coherence');

subplot(3,2,5)
plot(5:5:1000,smooth(cohe_all(1201:1400),moving_average),'bo-')
xlabel('lag distance (km)');
ylabel('log amplitude coherence');

subplot(3,2,6)
plot(5:5:1000,smooth(cohe_all(1501:1700),moving_average),'bo-')
xlabel('lag distance (km)');
ylabel('phase coherence');


%%%%%test inversion
test=zeros(100,1);for i=1:10000
test=test-100*2*M(1:200,:)'*(M(1:200,:)*test-smooth(cohe(1:200),10));test(test<0)=0;
clf;subplot(2,1,1);plot(5:5:1000,cohe(1:200),'bo');hold on;plot(5:5:1000,M(1:200,:)*test,'r','LineWidth',3);subplot(2,1,2);plot(0.003:0.003:0.3,test,'LineWidth',3);pause(0.01)
end

subplot(2,1,1)
xlabel('lag distance (km)');
ylabel('phase coherence');
subplot(2,1,1)
xlabel('wavenumber \kappa ( km^-^2)')
ylabel('power spectrum ');

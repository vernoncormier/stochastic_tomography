close all;
load phase_cohe.mat
count=zeros(100,1);
data=zeros(100,1);
%%here inc is spacing resolution!!
inc=10;

for i=1:length(coherence(:,1))
    lag=ceil(coherence(i,2)/inc+1);
    if lag < 101
        count(lag)=count(lag)+1;
        data(lag)=data(lag)+coherence(i,1);
    end
end
%lag=inc:inc:inc*300;
%coherence=data./count;
%data_density=count;
plot(inc:inc:inc*100,(data./count),'bo')
hold on;
plot(inc:inc:inc*100,smooth(data./count),'r','LineWidth',3)
data = data./count;
save phase_output_10.mat data

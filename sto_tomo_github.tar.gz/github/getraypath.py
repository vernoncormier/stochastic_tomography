from obspy.taup import TauPyModel
import numpy as np
model = TauPyModel(model="iasp91")
##Define the source and receivers
srcdepth=100.0
for distance in range(71,80,1):
    arrivals = model.get_ray_paths(srcdepth,distance)
    arrival = arrivals[0]
    raypathname='ray_2d_'+str(distance)
    np.savetxt(raypathname,arrival.path)
    print(distance)
 #    print(arrival.path.dtype)


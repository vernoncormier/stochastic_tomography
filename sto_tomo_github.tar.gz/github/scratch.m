%d=cohe_all(1:40); d(41:80)=cohe_all(301:340);
%M=M_japan_aa(1:40,:);M(41:80,:)=M_japan_pp(1:40,:);
%
%








N  = -1;
ag = 100;
av = 999;
kmap=0.003:0.003:0.3;
% kappa = sym('kappa',[1 40]); 
% generalp=sym(zeros(4000,1));
% for i=1:40
%     generalp(1+(i-1)*100:i*100)=kappa(i).^2 .*(av^-2 + kmap.^2).^( -1 - N) .* exp(-ag^2 .*kmap.^2/4);
% end
% 
% f=vpa(generalp,10);
% g=vpa(jacobian(generalp),10);
% coe_f=double(subs(f,kappa,1));
 for i=1:40
     generalp(1+(i-1)*100:i*100,1)=output;%(av^-2 + kmap.^2).^( -1 - N) .* exp(-ag^2 .*kmap.^2/4);
 end
 
test=40:-1:1;

f=zeros(4000,1);
g=zeros(4000,40);
percent_rate=0.1;
err=999;
errs=zeros(1,100000);
for i=1:1000000
    for j=1:40
        f(1+(j-1)*100:j*100)=generalp(1+(j-1)*100:j*100)*test(j)^2;
    end
    %subf=double(subs(f,kappa,test));
    %subg=double(subs(kappa,test));
    for j=1:40
        g(1+(j-1)*100:j*100,j)=generalp(1+(j-1)*100:j*100)*2*test(j);
    end
    inc=(M'*(M*f-d))'*g;
     if norm(M*f-d) > err
         percent_rate = percent_rate/2;
     end
    err = norm(M*f-d)
    
%     if mod(i,100)==0
%         percent_rate=0.01;
%     end
    gamma= abs(percent_rate*test./inc);
    test=test-inc.*gamma;
    
    plot(test);pause(0.01);
    errs(i)=err;
end
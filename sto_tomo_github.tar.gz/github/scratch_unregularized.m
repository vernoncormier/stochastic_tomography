% syms av ag N kappa kmap
% general_p=(kappa^2*exp(-(ag^2*kmap^2)/4))/(1/av^2 + kmap^2)^(N + 1);
% 
clear all
close all
load mapped_M
load cohe_all

lag = 150;
M=M_japan_aa(1:lag,:);
M(lag+1:lag*2,:)=M_japan_pp(1:lag,:);
M(lag*2+1:lag*3,:)=M_southam_aa(1:lag,:);
M(lag*3+1:lag*4,:)=M_southam_pp(1:lag,:);
M(lag*4+1:lag*5,:)=M_tonga_aa(1:lag,:);
M(lag*5+1:lag*6,:)=M_tonga_pp(1:lag,:);

d=cohe_all(1:lag);
d(lag+1:lag*2)=(cohe_all(301:300+lag));
d(lag*2+1:lag*3)=cohe_all(601:600+lag);
d(lag*3+1:lag*4)=(cohe_all(901:900+lag));
d(lag*4+1:lag*5)=cohe_all(1201:1200+lag);
d(lag*5+1:lag*6)=(cohe_all(1501:1500+lag));

kmap = (0.003:0.003:0.3)';

test = zeros(100,1)+0.1;
err= 999;

percent_rate=0.1;

for i = 1:10000000    
    
    f=test;
    
    inc = (M'*(M*f-d));
    
    if norm(M*f-d) > err
        percent_rate = percent_rate/2;
    end
    %[err err - norm(M_japan_pp*f-d)]
    err = norm(M*f-d);
    gamma_rate = abs(percent_rate*test./inc);
    
    test = test - gamma_rate.*inc;
     
    [ err err - norm(M*f-d)]
    
%    clf(subplot(4,2,7));plot(i,norm(M*f-d),'b.');hold on;
     a=hann(200);
     subplot(1,1,1);plot(kmap,(((f)).*a(101:200)));
%     subplot(4,2,1);plot(d(1:lag),'bo');hold on; plot(M(1:lag,:)*f);
%     subplot(4,2,2);plot(d(lag*1+1:lag*2),'bo');hold on; plot(M(lag*1+1:lag*2,:)*f);
%     subplot(4,2,3);plot(d(lag*2+1:lag*3),'bo');hold on; plot(M(lag*2+1:lag*3,:)*f);
%     subplot(4,2,4);plot(d(lag*3+1:lag*4),'bo');hold on; plot(M(lag*3+1:lag*4,:)*f);
%     subplot(4,2,5);plot(d(lag*4+1:lag*5),'bo');hold on; plot(M(lag*4+1:lag*5,:)*f);
%     subplot(4,2,6);plot(d(lag*5+1:lag*6),'bo');hold on; plot(M(lag*5+1:lag*6,:)*f);
    %plot(i,norm(M_japan_pp*f-d),'bo');hold on; 
    pause(0.1);


%%%%%To stop the iteration at specific confidence level, uncomment the following
% if err < 10^-10
% break;
% end

end

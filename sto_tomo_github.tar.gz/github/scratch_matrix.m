clear all;
close all;

iasp=load('IASP91');
c_ref = interp1(iasp(:,1),iasp(:,2),1:1000);

from_taup;
qs_raw = taup_data(40 : 88, 1) / 6371;
dq = (max(qs_raw) - min(qs_raw)) / 1000;
qs = min(qs_raw):dq:max(qs_raw);
angles = interp1(qs_raw, taup_data(40:88,2), qs);
distances= interp1(qs_raw, (40:88)+1, qs);

tau=zeros(length(qs),length(c_ref));%tau is a function of both q and z
                                    %theta is a function of q , z and kappa
for i=1:length(qs)
    for j=2:length(c_ref);
        tau(i,j)=trapz(1:j,sqrt(1./c_ref(1:j).^2-qs(i)^2));
    end
end

for j=1:length(c_ref)
    d1tau(:,j)=diff(tau(:,j))/dq;
    d2tau(:,j)=diff(diff(tau(:,j))/dq)/dq;
end

delta_angle=500;
q1=qs(1);
q2=qs(1+delta_angle);
ang1=angles(1);
ang2=angles(1+delta_angle);
d2tau1=d2tau(1,:);
d2tau2=d2tau(1+delta_angle,:);
d1tau1=d1tau(1,:);
d1tau2=d1tau(1+delta_angle,:);

kmap=0.0001:0.0001:1;
%kmap=logspace(-3,-1,100);
%                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
w=2*pi*0.5;

theta1 = 0.5 * d2tau1' * kmap.^2 / w^2;
theta2 = 0.5 * d2tau2' * kmap.^2 / w^2;

k=w./c_ref;
kq1=w.*sqrt(1./c_ref.^2-q1^2);
kq2=w.*sqrt(1./c_ref.^2-q2^2);
a1=k.^2./kq1;
a2=k.^2./kq2;

%R=zeros(600,length(c_ref));
%R=|(x1-r1)-(x2-r2)|,which is R=|x1-x2-r1+r2| =|lag-r1+r2| 
%Since in d1tau, all numbers are negative, we use lag+r1-r2
n=1;
for x=-300:299
    r1=d1tau1;
    r2=d1tau2;
    R(n,:)=abs(x+r2-r1);
    n=n+1;
end

a1a2=a1.*a2;
uutheta=sin(theta1).*sin(theta2);
pptheta=cos(theta1).*cos(theta2);


%Now calculate The matrix
 M=zeros(600*1,1000*3000);
 dh=1;
 dk=0.0001;
 for i=1:600
     waitbar(i/600);
     J_K_R=besselj(0,R(i,:)'*kmap);
     for z = 1:1000
         for k=1:3000
             aterm=a1a2(z);
             tterm=uutheta(z,k);
             jterm=J_K_R(z,k);
             M(i,(z-1)*3000+k)=0.5/pi*dh*aterm*tterm*kmap(k)*dk*jterm;
         end
     end
 end
save M.mat M -v7.3

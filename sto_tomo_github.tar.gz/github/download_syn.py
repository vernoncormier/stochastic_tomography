import os

from obspy 		import read_events
from obspy		import read_inventory

eventgroup=read_events("eventslist")
print(eventgroup)

stationgroup=read_inventory("stationslist")
print(stationgroup)

for i in range(len(eventgroup)):
	eventid=eventgroup[i].origins[0].resource_id.id.split('/')[-1].split('#')[0]
	try:
		foldername='./'+str(eventgroup[i].magnitudes[0].mag)+'_'+str(eventgroup[i].origins[0].latitude)+'_'+str(eventgroup[i].origins[0].longitude)+'_'+str(eventgroup[i].origins[0].depth)+'_'+eventid+'/'		
		commandline='curl -L --data-binary @'+foldername+'syngine.request -o '+foldername+'syngine.zip http://service.iris.edu/irisws/syngine/1/query'
		os.system(commandline)
		commandline='unzip '+foldername+'syngine.zip'+' -d '+foldername
		os.system(commandline)
		commandline='cat '+foldername+'Syngine.log'
		os.system(commandline)
		commandline='rm '+foldername+'syngine.zip ' +foldername+'Syngine.log'
		os.system(commandline)
		print("done event %d" %i)
	except:
		print("no folder in event %d" %i)

clear all
close all
load mapped_M_over_depth
load cohe_all
load inversion_result_unregularized_single_layer

lag = 100;
M=M_japan_aa(1:lag,:);
M(lag+1:lag*2,:)=M_japan_pp(1:lag,:);
M(lag*2+1:lag*3,:)=M_southam_aa(1:lag,:);
M(lag*3+1:lag*4,:)=M_southam_pp(1:lag,:);
M(lag*4+1:lag*5,:)=M_tonga_aa(1:lag,:);
M(lag*5+1:lag*6,:)=M_tonga_pp(1:lag,:);

d=cohe_all(1:lag);
d(lag+1:lag*2)=(cohe_all(301:300+lag));
d(lag*2+1:lag*3)=cohe_all(601:600+lag);
d(lag*3+1:lag*4)=(cohe_all(901:900+lag));
d(lag*4+1:lag*5)=cohe_all(1201:1200+lag);
d(lag*5+1:lag*6)=(cohe_all(1501:1500+lag));




N  = -1;
ag = 50;
av = 999;
kmap=0.003:0.003:0.3;
% kappa = sym('kappa',[1 40]); 
% generalp=sym(zeros(4000,1));
% for i=1:40
%     generalp(1+(i-1)*100:i*100)=kappa(i).^2 .*(av^-2 + kmap.^2).^( -1 - N) .* exp(-ag^2 .*kmap.^2/4);
% end
% 
% f=vpa(generalp,10); 
% g=vpa(jacobian(generalp),10);
% coe_f=double(subs(f,kappa,1));
a=hann(200);
 for i=1:40
     generalp(1+(i-1)*100:i*100,1)=(f./a(99:198)).*(f./a(99:198));%(av^-2 + kmap.^2).^( -1 - N) .* exp(-ag^2 .*kmap.^2/4);
 end

test=zeros(1,40)+0.1;%40:-1:1;

f=zeros(4000,1);
g=zeros(4000,40);
percent_rate=0.1;
err=999;
errs=zeros(1,100000);
for i=1:1000000
    for j=1:40
        f(1+(j-1)*100:j*100)=generalp(1+(j-1)*100:j*100)*test(j)^2;
    end
    %subf=double(subs(f,kappa,test));
    %subg=double(subs(kappa,test));
    for j=1:40
        g(1+(j-1)*100:j*100,j)=generalp(1+(j-1)*100:j*100)*2*test(j);
    end
    inc=(M'*(M*f-d))'*g;
     if norm(M*f-d) > err
         percent_rate = percent_rate/2;
     end
    err = norm(M*f-d);
    
    if mod(i,100)==0
        percent_rate=0.01;
    end
    gamma= abs(percent_rate*test./inc);
    test=test-inc.*gamma;
    
%    clf(subplot(4,2,7));plot(i,norm(err),'b.');hold on;
clf;
     subplot(4,2,8);plot(0:25:975,test);
    subplot(4,2,1);plot(d(1:lag),'bo');hold on; plot(M(1:lag,:)*f);
    subplot(4,2,2);plot(d(lag*1+1:lag*2),'bo');hold on; plot(M(lag*1+1:lag*2,:)*f);
    subplot(4,2,3);plot(d(lag*2+1:lag*3),'bo');hold on; plot(M(lag*2+1:lag*3,:)*f);
    subplot(4,2,4);plot(d(lag*3+1:lag*4),'bo');hold on; plot(M(lag*3+1:lag*4,:)*f);
    subplot(4,2,5);plot(d(lag*4+1:lag*5),'bo');hold on; plot(M(lag*4+1:lag*5,:)*f);
    subplot(4,2,6);plot(d(lag*5+1:lag*6),'bo');hold on; plot(M(lag*5+1:lag*6,:)*f);
    
    pause(0.0001);
    errs(i)=err;
%%To stop the iteration at specific confidence level, uncomment the following
% if err < 10^-10
% break;
% end

end

% 
% subplot(3,2,1);plot(5:5:lag*5,d(1:lag),'bo');hold on; plot(5:5:lag*5,smooth(M(1:lag,:)*f),'r','LineWidth',2);
% subplot(3,2,2);plot(5:5:lag*5,(d(lag*1+1:lag*2)),'bo');hold on; plot(5:5:lag*5,smooth(M(lag*1+1:lag*2,:)*f),'r','LineWidth',2);
% subplot(3,2,3);plot(5:5:lag*5,d(lag*2+1:lag*3),'bo');hold on; plot(5:5:lag*5,smooth(M(lag*2+1:lag*3,:)*f),'r','LineWidth',2);
% subplot(3,2,4);plot(5:5:lag*5,(d(lag*3+1:lag*4)),'bo');hold on; plot(5:5:lag*5,smooth(M(lag*3+1:lag*4,:)*f),'r','LineWidth',2);
% subplot(3,2,5);plot(5:5:lag*5,d(lag*4+1:lag*5),'bo');hold on; plot(5:5:lag*5,smooth(M(lag*4+1:lag*5,:)*f),'r','LineWidth',2);
% subplot(3,2,6);plot(5:5:lag*5,(d(lag*5+1:lag*6)),'bo');hold on; plot(5:5:lag*5,smooth(M(lag*5+1:lag*6,:)*f),'r','LineWidth',2);

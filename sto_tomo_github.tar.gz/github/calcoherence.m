load phase_fluctuations.mat
l=length(fluctuations_filtered);
phase_coherence=zeros(l*(l+1)/2,2);
n=1;
for i=1:l
    for j=i:l
        phase_coherence(n,1)=fluctuations_filtered(i)*fluctuations_filtered(j);
        phase_coherence(n,2)=distance(stations_latitude_filtered(i),stations_longitude_filtered(i),stations_latitude_filtered(j),stations_longitude_filtered(j));
        n=n+1;
    end
    waitbar(n/l/(l+1)*2);
end
phase_coherence(:,2)=phase_coherence(:,2)*6371*pi/180;
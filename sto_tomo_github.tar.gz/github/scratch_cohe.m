load phase_fluct.mat
l=length(fluctuations);
coherence=zeros(l*(l+1)/2,2);
n=1;
for i=1:l
    for j=i:l
        coherence(n,1)=fluctuations(i)*fluctuations(j);
        coherence(n,2)=distance(stations_latitude(i),stations_longitude(i),stations_latitude(j),stations_longitude(j));
        n=n+1;
    end
    finishing=i/l;
    finishing
end
coherence(:,2)=coherence(:,2)*6371*pi/180;
save phase_cohe.mat coherence

import glob

from obspy		import read
from obspy 		import read_events



eventgroup=read_events("eventslist")
print(eventgroup)

for i in range(len(eventgroup)):
	eventid=eventid=eventgroup[i].origins[0].resource_id.id.split('/')[-1].split('#')[0]
	foldername='./'+str(eventgroup[i].magnitudes[0].mag)+'_'+str(eventgroup[i].origins[0].latitude)+'_'+str(eventgroup[i].origins[0].longitude)+'_'+str(eventgroup[i].origins[0].depth)+'_'+eventid+'/'
	for filename in glob.glob(foldername+'*sac'):
		trace=read(filename)
		trace.filter('bandpass',freqmin=0.3,freqmax=2)
		trace.write(filename+'.syn', format="SAC")
	print("finished %d event in %d") %(i+1, len(eventgroup))

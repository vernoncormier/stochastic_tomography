#!/bin/bash
python download_syn.py > syngine.log

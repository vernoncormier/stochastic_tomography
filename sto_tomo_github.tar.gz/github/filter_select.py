import os

import math
from numpy import linalg as LA
import numpy as np

from obspy 		import UTCDateTime
from obspy		import read
from obspy 		import read_events
from obspy		import read_inventory
from obspy.taup 	import TauPyModel
from obspy.geodetics 	import locations2degrees 



eventgroup=read_events("eventslist")
#print(eventgroup)

stationgroup=read_inventory("stationslist")
#print(stationgroup)

model=TauPyModel(model="ak135")
number=[]
for i in range(len(eventgroup)):
	eventid=eventid=eventgroup[i].origins[0].resource_id.id.split('/')[-1].split('#')[0]
	n=0;
	for j1 in range(len(stationgroup.networks)):
		for j2 in range(len(stationgroup[j1].stations)):
			try:
				filename='./'+str(eventgroup[i].magnitudes[0].mag)+'_'+str(eventgroup[i].origins[0].latitude)+'_'+str(eventgroup[i].origins[0].longitude)+'_'+str(eventgroup[i].origins[0].depth)+'_'+eventid+'/'+stationgroup[j1].code+'_'+stationgroup[j1].stations[j2].code+'.SAC'
				trace=read(filename)
			except:
				continue
			trace.filter('bandpass',freqmin=0.3,freqmax=1.5)
			length=len(trace[0].data)
			noise=trace[0].data[0:length/3]
			signal=trace[0].data[length/7*3:length/7*4]
			snr2= np.std(signal)/np.std(noise)
			if snr2>5 :
				n=n+1;	
				trace.write(filename+'.SLC', format="SAC")
				#else:
					#print("not in time range",s120_before_arrival,s120_after_arrival,stationgroup[j1].stations[j2].creation_date,stationgroup[j1].stations[j2].termination_date)
	print("finished %d event in %d") %(i+1, len(eventgroup))
	print(n)
	number.append(n)
print(sum(number))
	#dataclient.get_waveforms_bulk(bulk=bulk,filename="seismograms_event"+str(i),attach_response=True)
	#traces=read("seismograms_event"+str(i))

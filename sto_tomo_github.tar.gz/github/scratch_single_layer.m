% syms av ag N kappa kmap
% general_p=(kappa^2*exp(-(ag^2*kmap^2)/4))/(1/av^2 + kmap^2)^(N + 1);
% 
% kmap = (0.003:0.003:0.3)';
% 
% f = (kappa^2*exp(-(ag^2.*kmap.^2)/4))./(1/av^2 + kmap.^2).^(N + 1);
% 
% g_av = (2*kappa^2*exp(-(ag^2.*kmap.^2)/4)*(N + 1))./(av^3*(1/av^2 + kmap.^2).^(N + 2));
% g_ag = -(ag*kappa^2.*kmap.^2.*exp(-(ag^2.*kmap.^2)/4))./(2*(1/av^2 + kmap.^2).^(N + 1));
% g_N = -(kappa^2.*log(1/av^2 + kmap.^2).*exp(-(ag^2.*kmap.^2)/4))./(1/av^2 + kmap.^2).^(N + 1);
% g_kappa = (2*kappa*exp(-(ag^2.*kmap.^2)/4))./(1/av^2 + kmap.^2).^(N + 1);
% 
% g=[g_av g_ag g_N g_kappa];

% for case of gaussian
kmap=(0.003:0.003:0.3)';
av=999;
N=-1;

test = [300,0.01];
err= 999;
percent_rate=0.01;
for i = 1:10000000
    
    ag = test(1);
    kappa = test(2);
    av = 999;
    N = -1;
    
    f = (kappa^2*exp(-(ag^2.*kmap.^2)/4))./(1/av^2 + kmap.^2).^(N + 1);
    g_av = (2*kappa^2*exp(-(ag^2.*kmap.^2)/4)*(N + 1))./(av^3*(1/av^2 + kmap.^2).^(N + 2));
    g_ag = -(ag*kappa^2.*kmap.^2.*exp(-(ag^2.*kmap.^2)/4))./(2*(1/av^2 + kmap.^2).^(N + 1));
    g_N = -(kappa^2.*log(1/av^2 + kmap.^2).*exp(-(ag^2.*kmap.^2)/4))./(1/av^2 + kmap.^2).^(N + 1);
    g_kappa = (2*kappa*exp(-(ag^2.*kmap.^2)/4))./(1/av^2 + kmap.^2).^(N + 1);
    g=[g_ag g_kappa];
    
    
    inc = (M_japan_pp'*(M_japan_pp*f-d))'*g;
    
    if norm(M_japan_pp*f-d) > err
        percent_rate = percent_rate/2;
    end
    %[err err - norm(M_japan_pp*f-d)]
    err = norm(M_japan_pp*f-d);
    gamma_rate = abs(percent_rate*test./inc);
    
    test = test - gamma_rate.*inc;
     
    [test gamma_rate.*inc err err - norm(M_japan_pp*f-d)]
    
    clf(subplot(2,1,2));plot(i,norm(M_japan_pp*f-d),'bo');hold on;
    subplot(2,1,1);plot(d,'bo');hold on; plot(M_japan_pp*f);
    %plot(i,norm(M_japan_pp*f-d),'bo');hold on; 
    pause(0.001);
%%To stop the iteration at specific confidence level, uncomment the following
% if err < 10^-10
% break;
% end



end
